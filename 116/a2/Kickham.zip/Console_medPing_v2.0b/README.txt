Tyler Kickham
a2

This program takes an input from the keyboard to tell it how many seconds to run the simulation for.  During the simulation it generates realistic vital signs for the patient and stores them into a struct, then prints all the records currently stored in the struct after each addition.  When the simulation time runs out it prompts the user to input the raw time of a record to delete.  The program will search for the record, and if found, delete it then print the remaining records.

This has been tested and works.
