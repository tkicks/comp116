Tyler Kickham
a1

This program will take three x values and three y values either through keyboard input or random generation and displays the information for the user to see. Also displayed are the numerator and denominator values for the r (correlation) equation. After these is the correlation coefficient and strength of association in both numeric and word form stating whether there is a strong or weak correlation between the x and y pairs.

This has been tested and works.
